import GuessGame
import requests

from Live import load_game, welcome,games


print(welcome("Guy"))
load_game(games)
